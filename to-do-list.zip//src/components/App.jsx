import React from "react";

function App() {
  const list = []
  const {list, setlist} = React.useState("");
  function t(item)
  {
    return (<li> {item} </li>);
  }
  function handleclick(event)
  {
    const name= event.target.value; 
    setlist(name);
    list.push(name);
    list.map(t);
    

  }
  return (
    <div className="container">
      <div className="heading">
        <h1>To-Do List</h1>
      </div>
      <div className="form">
        <input type="text" value="list" onChange={change}/>
        <button>
          <span>Add</span>
        </button onClick={handleclick}>
      </div>
      <div>
        <ul>
          <li>{item}</li>
        </ul>
      </div>
    </div>
  );
}

export default App;
